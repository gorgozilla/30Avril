<?php
$SNP_THEMES['builder']		 = array(
    'STYLES'	 => 'style.css',
    'OPEN_FUNCTION'	 => 'snp_bld_open',
    'CLOSE_FUNCION'	 => 'snp_bld_close'
    );
?>